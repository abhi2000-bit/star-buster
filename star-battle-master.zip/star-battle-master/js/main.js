(() => {
    const game = new Game();
    game.start();
})();